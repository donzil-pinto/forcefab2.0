# Step 10 changes

- The Dashboard Total Lot Holds card opens Fab Lots filtered to records with Engineering Hold = Yes.
- Added a dedicated Case Details page with a Case ID lookup, case information, Chronology & Decisions, and Human Actions.
- Added persistent case actions for review, assignment, notes, disposition recommendation, approval routing, lot holds, escalation, close, and reopen.
- Routed recommendations appear in the Approval Inbox for the configured approval role and permitted site scope.
- Case workflow data is stored in `data/case_workflow.sqlite3`; the packaged legacy database remains read-only.
