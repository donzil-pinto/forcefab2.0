# Step 12 changes

- Dashboard Total Lot Holds opens Fab Lots filtered to records whose Engineering Hold value is `Yes` or `1`.
- Fab Lots Lot ID, Approval Case ID, and Events Case ID use the same clickable styling as Case ID in the Cases table.
- Case Details places Human Actions above Case Information.
- Case Details disables all actions except Re-open for closed cases, disables Re-open for non-closed cases, and disables Start Review for UNDER_REVIEW, PENDING_APPROVAL, ACCEPTED, and REJECTED cases.
- Renamed Approve to Approval Review.
- Disabled buttons on Case Details use greyed-out styling.
- Start Review is enabled only when Case Status is OPEN or REOPEN.
- Recommend and Request Approval are disabled when Case Status is OPEN or REOPEN.
- Human Actions displays every action button to all users; buttons remain disabled when the user lacks its required privilege or the case status does not allow the action.
