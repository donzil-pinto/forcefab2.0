# Step 11 changes

- Dashboard Total Lot Holds opens Fab Lots with a filter that includes engineering hold values `1`, `Yes`, or `true` and excludes other values.
- Role Management offers the `write`, `delete`, `approve`, `disposition`, and `reopen` privileges.
- Cases no longer displays the “Select a case row to open its form.” prompt, and the Open Cases table uses the full available width.
- Case Details shows Case Information beside Chronology & Decisions. Recommend, Re-open, and Approve controls are shown according to role privileges. Approval requires Accept or Reject and a note; the API enforces the same privileges and records the decision in case status and chronology.
- Approvals displays a table of cases whose current workflow status is `PENDING_APPROVAL`, with the Cases columns except Status.
