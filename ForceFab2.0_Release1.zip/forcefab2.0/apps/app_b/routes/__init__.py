"""Application B HTTP routes."""
