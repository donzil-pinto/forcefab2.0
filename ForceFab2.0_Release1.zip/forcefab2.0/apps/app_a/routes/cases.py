"""GET /api/cases/{id}. SCH-06 body. Optional cited explanation."""
from __future__ import annotations

from datetime import datetime, timezone
from fastapi import APIRouter, Request
from fastapi.responses import JSONResponse

from apps.app_a.agent.waiting import overlay_for_case
from apps.app_a.events import record_event
from apps.app_a.intelligence.generate import generate
from apps.app_a.store import approval_inbox, get_case, record_case_action
from apps.shared.site_scope import site_visible
from apps.shared.identity import HEADER_ACTOR_ID, HEADER_ACTOR_ROLE, HEADER_CORRELATION, header_get
from apps.shared.identity import error_body

router = APIRouter()

RECOMMEND_ACTIONS = {"Rework", "Release", "Scrap", "Downgrade", "Continue Review"}
SEVERITIES = ["LOW", "MEDIUM", "HIGH", "CRITICAL"]


@router.post("/api/cases/{case_id}/actions")
async def case_action(case_id: str, request: Request, payload: dict) -> JSONResponse:
    case = get_case(case_id)
    if case is None:
        return JSONResponse(error_body("not_found", "No Application A case has that id."), status_code=404)
    claims = getattr(request.state, "claims", None) or {}
    if not site_visible(claims.get("sites") or [], case.get("site"), case_id):
        return JSONResponse(error_body("site_forbidden", "This record is outside the sites on the sign-in token."), status_code=403)
    action = str(payload.get("action") or "")
    actor_id = header_get(request.headers, HEADER_ACTOR_ID)
    actor_role = header_get(request.headers, HEADER_ACTOR_ROLE)
    notes = str(payload.get("notes") or payload.get("rationale") or "").strip()
    if action in {"add_note", "recommend", "request_approval", "record_hold", "escalate", "close", "reopen"} and not notes:
        return JSONResponse({"ok": False, "message": "Enter notes or a reason for this action."}, status_code=400)
    if action == "recommend" and payload.get("recommend_action") not in RECOMMEND_ACTIONS:
        return JSONResponse({"ok": False, "message": "Choose a valid recommended disposition."}, status_code=400)
    if action == "escalate":
        current = str(case.get("severity") or "LOW").upper()
        target = str(payload.get("severity") or (SEVERITIES[min(3, SEVERITIES.index(current) + 1)] if current in SEVERITIES else "HIGH")).upper()
        if target not in SEVERITIES or (current in SEVERITIES and SEVERITIES.index(target) <= SEVERITIES.index(current)):
            return JSONResponse({"ok": False, "message": "Escalation must increase the case severity."}, status_code=400)
        payload["severity"] = target
    if action == "request_approval" and not case.get("recommendation"):
        return JSONResponse({"ok": False, "message": "Add a disposition recommendation before requesting approval."}, status_code=409)
    allowed = {"start_review", "assign", "add_note", "recommend", "request_approval", "record_hold", "escalate", "close", "reopen"}
    if action not in allowed:
        return JSONResponse({"ok": False, "message": "That case action is not supported."}, status_code=400)
    if action == "assign" and not str(payload.get("owner_id") or "").strip():
        return JSONResponse({"ok": False, "message": "Choose an existing user to assign."}, status_code=400)
    event = {
        "action": action,
        "action_taken": str(payload.get("action_taken") or action.replace("_", " ").title()),
        "owner": actor_id,
        "owner_id": actor_id if action == "start_review" else str(payload.get("owner_id") or ""),
        "timestamp": datetime.now(timezone.utc).isoformat(),
        "notes": notes,
        "actor_role": actor_role,
        "recommend_action": payload.get("recommend_action"),
        "rationale": str(payload.get("rationale") or "").strip(),
        "severity": payload.get("severity"),
    }
    updated = record_case_action(case_id, event)
    return JSONResponse({"ok": True, "case": updated, "action": event})


@router.get("/api/cases/approval-inbox")
def case_approval_inbox(request: Request) -> JSONResponse:
    claims = getattr(request.state, "claims", None) or {}
    sites = claims.get("sites") or []
    items = [item for item in approval_inbox() if site_visible(sites, (get_case(str(item.get("case_id") or "")) or {}).get("site"), str(item.get("case_id") or ""))]
    return JSONResponse({"ok": True, "items": items})

SCENARIO_EVENTS = {
    "SP-07": "EV-02",
    "SP-08": "EV-04",
    "SP-09": "EV-05",
    "SP-10": "EV-06",
    "SP-11": "EV-11",
}


@router.get("/api/cases/{case_id}")
def get_case_route(case_id: str, request: Request, explain: bool = True) -> JSONResponse:
    body = get_case(case_id)
    correlation_id = header_get(request.headers, HEADER_CORRELATION) or None
    if body is None:
        return JSONResponse(
            error_body(
                "not_found",
                "No Application A case has that id.",
                correlation_id=correlation_id,
            ),
            status_code=404,
        )
    waiting = overlay_for_case(case_id)
    if waiting:
        body = dict(body)
        if waiting.get("waiting_role"):
            body["waiting_role"] = waiting.get("waiting_role")
        if waiting.get("draft_plan"):
            body["draft_plan"] = waiting.get("draft_plan")
        body["correlation_id"] = waiting.get("correlation_id")
    actor_id = header_get(request.headers, HEADER_ACTOR_ID)
    actor_role = header_get(request.headers, HEADER_ACTOR_ROLE)
    event_type = SCENARIO_EVENTS.get(body.get("scenario") or "")
    if event_type:
        record_event(
            event_type,
            correlation_id=correlation_id,
            actor_id=actor_id,
            actor_role=actor_role,
            case_id=case_id,
            lake_item_ids=list(body.get("citation_targets") or []),
        )
    explanation = None
    if explain:
        question = body.get("explain_question") or f"Explain case {case_id}."
        explanation = generate(
            question,
            prompt_id="P-EXPLAIN-CONFLICT",
            case_id=case_id,
            hint_item_ids=list(body.get("citation_targets") or []),
        )
        body = dict(body)
        body["sentence"] = explanation.get("sentence")
        body["citations"] = explanation.get("citations")
        body["verdict"] = explanation.get("verdict")
        body["block"] = explanation.get("block")
        if explanation.get("untrusted_quotes"):
            body["untrusted_quotes"] = explanation.get("untrusted_quotes")
        if explanation.get("draft_plan"):
            body["draft_plan"] = explanation.get("draft_plan")
        if explanation.get("error_class"):
            body["error_class"] = explanation.get("error_class")
    return JSONResponse({"ok": True, "case": body, "explanation": explanation})
