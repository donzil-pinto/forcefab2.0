"""Application A HTTP routes."""
