"""Dummy users and clients for the local identity provider."""
from __future__ import annotations

import json
import sqlite3

from apps.identity.crypto_util import DEMO_TOTP_SECRET, hash_password

DEMO_PASSWORD = "ForceFab-Demo-2026!"

USERS = (
    ("reviewer.tw", "Mei Chen", ("RT-01",), ("FAB-01",), True),
    ("shiftlead.tw", "Wei Lin", ("RT-02",), ("FAB-01",), True),
    ("engineer.az", "Jordan Patel", ("RT-03",), ("FAB-02",), True),
    ("policy.owner", "Sofia Alvarez", ("RT-04",), ("FAB-01", "FAB-02"), True),
    ("analyst.az", "Liam Brooks", ("RT-05",), ("FAB-02",), False),
    ("opslead", "Ava Huang", ("RT-06",), ("FAB-01", "FAB-02"), True),
    ("admin", "John Force", ("RT-07",), ("FAB-01", "FAB-02"), True),
    ("auditor", "Grace Kim", ("FF-AUDITOR",), ("FAB-01", "FAB-02"), True),
    ("breakglass", "Break Glass", ("FF-ADMIN", "RT-02"), ("FAB-01", "FAB-02"), True),
)

CLIENTS = (
    (
        "force-fab-app-a",
        "confidential",
        "dev-secret-a",
        (
            "http://127.0.0.1:8100/auth/callback",
            "http://localhost:8100/auth/callback",
        ),
        "force-fab-app-a",
    ),
    (
        "force-fab-app-b",
        "confidential",
        "dev-secret-b",
        (
            "http://127.0.0.1:8110/auth/callback",
            "http://localhost:8110/auth/callback",
        ),
        "force-fab-app-b",
    ),
    ("force-fab-svc-a", "client_credentials", "dev-svc-a", (), "force-fab-lake"),
    ("force-fab-svc-b", "client_credentials", "dev-svc-b", (), "force-fab-lake"),
    ("force-fab-scim", "client_credentials", "dev-scim", (), "force-fab-scim"),
)

ROLES = (
    "RT-01",
    "RT-02",
    "RT-03",
    "RT-04",
    "RT-05",
    "RT-06",
    "RT-07",
    "FF-ADMIN",
    "FF-AUDITOR",
    "SVC",
    "SCIM",
)

FAB_GROUPS = (
    ("FAB-01", "Fab Group 01", ("JP-KN", "IN-BLR", "DE-BY")),
    ("FAB-02", "Fab Group 02", ("BR-SP", "US-TX", "GB-ENG")),
)


def seed(conn: sqlite3.Connection) -> None:
    if not conn.execute("SELECT 1 FROM identity_meta WHERE key='fab_groups_seeded'").fetchone():
        for group_id, name, sites in FAB_GROUPS:
            conn.execute(
                "INSERT OR IGNORE INTO fab_groups(group_id,name,sites_json) VALUES(?,?,?)",
                (group_id, name, json.dumps(list(sites), separators=(",", ":"))),
            )
        conn.execute("INSERT INTO identity_meta(key,value) VALUES('fab_groups_seeded','1')")
    # Carry forward access labels and direct site assignments from older local
    # databases once, while keeping later admin deletions persistent.
    if not conn.execute("SELECT 1 FROM identity_meta WHERE key='user_sites_migrated'").fetchone():
        site_to_group = {site: group_id for group_id, _name, sites in FAB_GROUPS for site in sites}
        group_ids = {row["group_id"] for row in conn.execute("SELECT group_id FROM fab_groups")}
        for row in conn.execute("SELECT user_id,site FROM user_sites"):
            group_id = row["site"] if row["site"] in {item[0] for item in FAB_GROUPS} else site_to_group.get(row["site"])
            if group_id in group_ids:
                conn.execute("INSERT OR IGNORE INTO user_fab_groups(user_id,group_id) VALUES(?,?)", (row["user_id"], group_id))
        conn.execute("INSERT INTO identity_meta(key,value) VALUES('user_sites_migrated','1')")
    labels = {
        "RT-01": "Fab Exception Reviewer", "RT-02": "Shift Lead", "RT-03": "Process Engineer",
        "RT-04": "Policy Owner", "RT-05": "Operations Analyst", "RT-06": "Operations Lead",
        "RT-07": "Platform Administrator", "FF-ADMIN": "Legacy Platform Administrator",
        "FF-AUDITOR": "Auditor", "SVC": "Service Account", "SCIM": "Directory Provisioning",
    }
    for name in ROLES:
        conn.execute("INSERT OR IGNORE INTO roles(name) VALUES (?)", (name,))
        conn.execute("INSERT OR IGNORE INTO role_details(role,label,privileges_json) VALUES(?,?,?)", (name, labels.get(name, name), json.dumps(["*"], separators=(",", ":")) if name in ("RT-07", "FF-ADMIN") else json.dumps(["read"], separators=(",", ":"))))
    existing = conn.execute("SELECT COUNT(*) AS n FROM users").fetchone()["n"]
    if existing:
        conn.execute("UPDATE users SET email=lower(replace(trim(name),' ','.')) || '@fabpulse.com' WHERE email LIKE '%@force-fab.local'")
        conn.execute("INSERT OR IGNORE INTO roles(name) VALUES ('RT-07')")
        conn.execute("INSERT OR IGNORE INTO role_details(role,label,privileges_json) VALUES(?,?,?)", ("RT-07", "Platform Administrator", json.dumps(["*"], separators=(",", ":"))))
        admin = conn.execute("SELECT id FROM users WHERE username='admin'").fetchone()
        if admin is None:
            digest = hash_password(DEMO_PASSWORD)
            cur = conn.execute("INSERT INTO users(username,name,email,password_hash,active,mfa_secret,mfa_enrolled,first_name,last_name) VALUES('admin','John Force','john.force@fabpulse.com',?,1,?,1,'John','Force')", (digest, DEMO_TOTP_SECRET))
            admin_id = cur.lastrowid
            conn.execute("INSERT INTO user_roles(user_id,role) VALUES(?, 'RT-07')", (admin_id,))
            for group_id in ("FAB-01", "FAB-02"):
                conn.execute("INSERT INTO user_fab_groups(user_id,group_id) VALUES(?,?)", (admin_id, group_id))
        else:
            conn.execute("UPDATE users SET name='John Force',email='john.force@fabpulse.com',first_name='John',last_name='Force' WHERE id=?", (admin['id'],))
            conn.execute("INSERT OR IGNORE INTO user_roles(user_id,role) VALUES(?, 'RT-07')", (admin['id'],))
            conn.execute("DELETE FROM user_roles WHERE user_id=? AND role='FF-ADMIN'", (admin['id'],))
        conn.commit()
        return
    password_hash = hash_password(DEMO_PASSWORD)
    for username, name, roles, sites, enrolled in USERS:
        secret = DEMO_TOTP_SECRET if enrolled else None
        cur = conn.execute(
            """
            INSERT INTO users(username, name, email, password_hash, active, mfa_secret, mfa_enrolled, first_name, last_name)
            VALUES (?, ?, ?, ?, 1, ?, ?, ?, ?)
            """,
            (username, name, f"{name.lower().replace(' ', '.')}@fabpulse.com", password_hash, secret, 1 if enrolled else 0, name.split()[0], " ".join(name.split()[1:])),
        )
        user_id = cur.lastrowid
        for role in roles:
            conn.execute("INSERT INTO user_roles(user_id, role) VALUES (?, ?)", (user_id, role))
        for group_id in sites:
            conn.execute("INSERT OR IGNORE INTO user_fab_groups(user_id, group_id) VALUES (?, ?)", (user_id, group_id))
    for client_id, client_type, secret, redirects, aud in CLIENTS:
        conn.execute(
            """
            INSERT INTO clients(client_id, secret_hash, client_type, redirect_uris, token_aud)
            VALUES (?, ?, ?, ?, ?)
            """,
            (client_id, hash_password(secret), client_type, json.dumps(list(redirects)), aud),
        )
    conn.commit()
