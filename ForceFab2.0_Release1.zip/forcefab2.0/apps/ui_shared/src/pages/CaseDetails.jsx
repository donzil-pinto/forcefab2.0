import { useEffect, useMemo, useState } from "react";
import { callApi } from "../api.js";
import { go, PageHead, useFetch } from "./kit.jsx";

const WRITE_ACTIONS = ["Start Review", "Assign", "Add Note", "Record Hold", "Escalate", "Close"];
const RECOMMENDATIONS = ["Rework", "Release", "Scrap", "Downgrade", "Continue Review"];
const pretty = (value) => value == null || value === "" ? "—" : typeof value === "object" ? JSON.stringify(value) : String(value);

export function CaseDetails({ route, me, onUnauth }) {
  const caseId = route.parts[1] ? decodeURIComponent(route.parts[1]) : "";
  const params = route.params;
  const [refresh, setRefresh] = useState(0);
  const detail = useFetch(caseId ? `/api/cases/${encodeURIComponent(caseId)}/detail?refresh=${refresh}` : "", onUnauth);
  const [caseLookup, setCaseLookup] = useState(caseId);
  const [assignees, setAssignees] = useState([]);
  const [userSearch, setUserSearch] = useState("");
  const [action, setAction] = useState("");
  const [form, setForm] = useState({});
  const [notice, setNotice] = useState("");
  const [saving, setSaving] = useState(false);
  useEffect(() => {
    setCaseLookup(caseId);
  }, [caseId]);
  useEffect(() => {
    if (!caseId) return;
    callApi("/api/identity/case-assignees").then(({ status, data }) => { if (status === 200) setAssignees(data.users || []); });
  }, [caseId]);
  const selectedUser = useMemo(() => assignees.find((user) => user.username === form.owner_id), [assignees, form.owner_id]);
  async function submit(event) {
    event.preventDefault();
    if (!action) return;
    setSaving(true); setNotice("");
    const actionKey = action === "Re-open" ? "reopen" : action === "Approval Review" ? "approve" : action.toLowerCase().replaceAll(" ", "_");
    const body = { ...form, action: actionKey };
    const result = await callApi(`/api/cases/${encodeURIComponent(caseId)}/actions`, null, { method: "POST", body });
    setSaving(false);
    if (result.status >= 400 || result.data?.ok === false) { setNotice(result.data?.message || "The action could not be saved."); return; }
    setNotice(`${action} recorded.`); setAction(""); setForm({}); setRefresh((value) => value + 1);
    window.dispatchEvent(new Event("ff-case-updated"));
  }
  const status = detail.data?.case?.status || "Unknown";
  const normalizedStatus = String(status).toUpperCase();
  const isClosed = normalizedStatus === "CLOSED";
  const disableStartReview = !["OPEN", "REOPEN"].includes(normalizedStatus);
  const disableOpenCaseActions = ["OPEN", "REOPEN"].includes(normalizedStatus);
  const severity = detail.data?.case?.severity || "Unknown";
  const caseFields = detail.data?.case || {};
  const privileges = new Set(me?.privileges || []);
  const can = (name) => privileges.has(name) || privileges.has("*");
  const actions = [...WRITE_ACTIONS, "Recommend", "Request Approval", "Approval Review", "Re-open"];
  const requiredPrivilege = (label) => label === "Recommend" ? "disposition" : label === "Approval Review" ? "approve" : label === "Re-open" ? "reopen" : "write";
  const timeline = [...(detail.data?.timeline || [])].sort((a, b) => String(a.recorded_at || a.timestamp || "").localeCompare(String(b.recorded_at || b.timestamp || "")));
  function showCase(event) {
    event.preventDefault();
    const id = caseLookup.trim();
    if (!id) return;
    go(`/case-details/${encodeURIComponent(id)}${params.toString() ? `?${params.toString()}` : ""}`);
  }
  return <div className="case-details-page" data-refresh={refresh}>
    <PageHead kicker="Analysis & Audit" title="Case Details" sentence="Enter a Case ID to view its information, chronology, decisions, and available human actions." />
    <form className="ff-filters" onSubmit={showCase}>
      <label>Case ID<input name="case_id" placeholder="C00000006" value={caseLookup} onChange={(event) => setCaseLookup(event.target.value)} /></label>
      <button type="submit" className="primary">Show Case</button>
    </form>
    {detail.loading ? <p role="status">Loading case details…</p> : null}{detail.error ? <p role="alert">{detail.error}</p> : null}
    {caseId && detail.data?.case ? <>
        <section className="ff-card case-details-header">
          <p className="band-kicker">Case</p><h2>{caseId}</h2>
          <div className="case-status-severity"><span className="status-chip">Status · {status}</span><span className={`severity-chip severity-${String(severity).toLowerCase()}`}>Severity · {severity}</span></div>
        </section>
        <section className="ff-card case-human-actions"><h2>Human Actions</h2><div className="case-action-buttons">{actions.map((label) => <button type="button" key={label} className={label === "Start Review" || label === "Approval Review" ? "primary" : "quiet"} disabled={!can(requiredPrivilege(label)) || (isClosed && label !== "Re-open") || (!isClosed && label === "Re-open") || (label === "Start Review" && disableStartReview) || (["Recommend", "Request Approval"].includes(label) && disableOpenCaseActions) || (label === "Approval Review" && normalizedStatus !== "PENDING_APPROVAL")} onClick={() => { setAction(label); setForm({}); setNotice(""); }}>{label}</button>)}</div>
          {action && (!isClosed || action === "Re-open") ? <form className="case-action-form" onSubmit={submit}><h3>{action}</h3>
            {action === "Assign" ? <><label htmlFor="case-user-search">Search users<input id="case-user-search" value={userSearch} onChange={(event) => setUserSearch(event.target.value)} placeholder="Name or username" /></label><label htmlFor="case-owner">Assign owner<select id="case-owner" required value={form.owner_id || ""} onChange={(event) => setForm({ ...form, owner_id: event.target.value })}><option value="">Select a user</option>{assignees.filter((user) => `${user.name} ${user.username}`.toLowerCase().includes(userSearch.toLowerCase())).map((user) => <option key={user.username} value={user.username}>{user.name} · {user.username}</option>)}</select></label>{selectedUser ? <p>Selected: {selectedUser.name}</p> : null}</> : null}
            {action === "Recommend" ? <label htmlFor="case-recommend">Recommend Action<select id="case-recommend" required value={form.recommend_action || ""} onChange={(event) => setForm({ ...form, recommend_action: event.target.value })}><option value="">Choose disposition</option>{RECOMMENDATIONS.map((item) => <option key={item}>{item}</option>)}</select></label> : null}
            {action === "Approval Review" ? <label htmlFor="case-approval-decision">Decision<select id="case-approval-decision" required value={form.decision || ""} onChange={(event) => setForm({ ...form, decision: event.target.value })}><option value="">Choose Accept or Reject</option><option value="accept">Accept</option><option value="reject">Reject</option></select></label> : null}
            {action === "Record Hold" ? <label htmlFor="case-lot">Related Lot ID<input id="case-lot" value={form.lot_id || ""} placeholder="Auto-detected from case ID when blank" onChange={(event) => setForm({ ...form, lot_id: event.target.value })} /></label> : null}
            {["Add Note", "Recommend", "Request Approval", "Record Hold", "Escalate", "Close", "Re-open", "Start Review", "Approval Review"].includes(action) ? <label htmlFor="case-notes">{action === "Recommend" ? "Rationale" : action === "Record Hold" ? "Hold rationale" : "Note / Reason"}<textarea id="case-notes" required={action !== "Start Review"} rows="3" value={form.notes || ""} onChange={(event) => setForm({ ...form, notes: event.target.value })} /></label> : null}
            <div className="profile-actions"><button type="submit" className="primary" disabled={saving}>{saving ? "Saving…" : action === "Approval Review" ? "Submit decision" : `Confirm ${action}`}</button><button type="button" className="quiet" onClick={() => setAction("")}>Cancel</button></div>
          </form> : null}{notice ? <p role="status">{notice}</p> : null}
        </section>
        <div className="case-detail-layout"><section className="ff-card"><h2>Case Information</h2><dl className="case-fields">{Object.entries(caseFields).filter(([, value]) => value != null).map(([key, value]) => <div key={key}><dt>{key.replaceAll("_", " ")}</dt><dd>{pretty(value)}</dd></div>)}</dl></section>
        <section className="ff-card"><h2>Chronology &amp; Decisions</h2>
          {timeline.length ? <ol className="case-timeline">{timeline.map((entry, index) => <li key={`${entry.sequence || index}-${entry.recorded_at || entry.timestamp || index}`}><time>{entry.recorded_at || entry.timestamp || entry.occurred_at || ""}</time><strong>{entry.action || entry.event_type || entry.kind || "Case event"}</strong><span>Owner: {entry.owner || entry.actor_id || "System"}</span>{entry.notes ? <p>{entry.notes}</p> : null}{entry.details && Object.keys(entry.details).length ? <small>{Object.entries(entry.details).map(([key, value]) => `${key.replaceAll("_", " ")}: ${pretty(value)}`).join(" · ")}</small> : null}{entry.payload && Object.keys(entry.payload).length ? <small>{JSON.stringify(entry.payload)}</small> : null}</li>)}</ol> : <p>No chronology entries are recorded yet.</p>}
        </section></div>
    </> : null}
  </div>;
}
