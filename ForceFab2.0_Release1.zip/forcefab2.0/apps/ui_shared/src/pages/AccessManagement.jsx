import { useEffect, useState } from "react";
import { callApi } from "../api.js";

const emptyUser = {username:"",first_name:"",last_name:"",email:"",roles:[],fab_groups:[],active:true};
const emptyRole = {name:"",label:"",privileges:[]};
const GROUP_SITES = ["JP-KN", "IN-BLR", "DE-BY", "BR-SP", "US-TX", "GB-ENG"];
const emptyGroup = {group_id:"",name:"",sites:[]};
const PRIVILEGE_OPTIONS = ["read", "write", "delete", "approve", "disposition", "reopen", "*"];

export function AccessManagement({ page, me }) {
  const [roles,setRoles] = useState([]);
  const [users,setUsers] = useState([]);
  const [groups,setGroups] = useState([]);
  const [role,setRole] = useState(emptyRole);
  const [user,setUser] = useState(emptyUser);
  const [editingUser,setEditingUser] = useState("");
  const [editingRole,setEditingRole] = useState("");
  const [group,setGroup] = useState(emptyGroup);
  const [editingGroup,setEditingGroup] = useState("");
  const [message,setMessage] = useState("");
  const [loading,setLoading] = useState(true);
  const isRoles = page === "admin-roles";
  const isGroups = page === "admin-fab-groups";

  async function load() {
    setLoading(true);
    const results = await Promise.all([callApi("/api/identity/admin/roles"),callApi("/api/identity/admin/users"),callApi("/api/identity/admin/fab-groups")]);
    if (results[0].status === 200) setRoles(results[0].data.roles || []);
    if (results[1].status === 200) setUsers(results[1].data.users || []);
    if (results[2].status === 200) setGroups(results[2].data.fab_groups || []);
    setLoading(false);
  }
  useEffect(()=>{load().catch(()=>{setMessage("Unable to load administration data.");setLoading(false);});},[]);

  async function saveRole(event) {
    event.preventDefault();
    const path = "/api/identity/admin/roles" + (editingRole ? "/" + encodeURIComponent(editingRole) : "");
    const result = await callApi(path,me,{method:editingRole?"PUT":"POST",body:role});
    setMessage(result.data.message || (result.status < 300 ? "Role saved." : "Unable to save role."));
    if(result.status < 300){setRole(emptyRole);setEditingRole("");await load();}
  }
  async function deleteRole(name) {
    const result=await callApi("/api/identity/admin/roles/"+encodeURIComponent(name),me,{method:"DELETE"});
    setMessage(result.data.message || (result.status < 300 ? "Role deleted." : "Unable to delete role."));
    if(result.status < 300)await load();
  }
  async function saveUser(event) {
    event.preventDefault();
    const path="/api/identity/admin/users"+(editingUser?"/"+encodeURIComponent(editingUser):"");
    const result=await callApi(path,me,{method:editingUser?"PUT":"POST",body:user});
    setMessage(result.data.message || (result.status < 300 ? "User saved." : "Unable to save user."));
    if(result.status < 300){setUser(emptyUser);setEditingUser("");await load();}
  }
  async function deleteUser(username) {
    const result=await callApi("/api/identity/admin/users/"+encodeURIComponent(username),me,{method:"DELETE"});
    setMessage(result.data.message || (result.status < 300 ? "User deleted." : "Unable to delete user."));
    if(result.status < 300)await load();
  }
  async function saveGroup(event) {
    event.preventDefault();
    const path="/api/identity/admin/fab-groups"+(editingGroup?"/"+encodeURIComponent(editingGroup):"");
    const result=await callApi(path,me,{method:editingGroup?"PUT":"POST",body:group});
    setMessage(result.data.message || (result.status<300?"Fab Group saved.":"Unable to save Fab Group."));
    if(result.status<300){setGroup(emptyGroup);setEditingGroup("");await load();}
  }
  async function deleteGroup(groupId) {
    const result=await callApi("/api/identity/admin/fab-groups/"+encodeURIComponent(groupId),me,{method:"DELETE"});
    setMessage(result.data.message || (result.status<300?"Fab Group deleted. Its user assignments were removed.":"Unable to delete Fab Group."));
    if(result.status<300)await load();
  }
  function toggle(list,value) { return list.includes(value) ? list.filter((x)=>x!==value) : [...list,value]; }

  return <section className="console">
    <header className="ff-page-head"><p className="band-kicker">Administration</p><h1 className="ff-title">{isRoles?"Role Management":isGroups?"Fab Group Management":"User Management"}</h1><p>{isRoles?"Manage application roles and privileges.":isGroups?"Manage Fab Groups and the sites assigned to each group.":"Manage users, role assignments, and Fab Group access."}</p></header>
    {message?<p role="status" className="admin-status">{message}</p>:null}
    {loading?<p role="status">Loading administration data…</p>:null}
    {isGroups ? <>
      <form className="ff-card admin-form" onSubmit={saveGroup}>
        <h2>{editingGroup?"Edit "+editingGroup:"Create Fab Group"}</h2>
        <div className="profile-grid"><label>Fab Group ID<input required disabled={Boolean(editingGroup)} value={group.group_id} onChange={(e)=>setGroup({...group,group_id:e.target.value.toUpperCase()})}/></label><label>Fab Group Name<input required value={group.name} onChange={(e)=>setGroup({...group,name:e.target.value})}/></label></div>
        <fieldset className="role-picker"><legend>Fab Group Sites</legend>{GROUP_SITES.map((site)=><label key={site}><input type="checkbox" checked={group.sites.includes(site)} onChange={()=>setGroup({...group,sites:toggle(group.sites,site)})}/>{site}</label>)}</fieldset>
        <div className="profile-actions"><button className="primary-action">{editingGroup?"Save Fab Group":"Create Fab Group"}</button><button type="button" className="quiet" onClick={()=>{setGroup(emptyGroup);setEditingGroup("");}}>Clear</button></div>
      </form>
      <div className="ff-card"><h2>Fab Groups</h2><div className="admin-list">{groups.map((item)=><article className="admin-row" key={item.group_id}><div><strong>{item.group_id}</strong><span>{item.name}</span><small>{(item.sites||[]).join(", ")}</small></div><div className="row-actions"><button type="button" className="quiet" onClick={()=>{setGroup({group_id:item.group_id,name:item.name,sites:item.sites||[]});setEditingGroup(item.group_id);}}>Edit</button><button type="button" className="quiet danger-action" onClick={()=>deleteGroup(item.group_id)}>Delete</button></div></article>)}</div></div>
    </> : isRoles ? <>
      <form className="ff-card admin-form" onSubmit={saveRole}>
        <h2>{editingRole?"Edit "+editingRole:"Create role"}</h2>
        <div className="profile-grid"><label>Role code<input required disabled={Boolean(editingRole)} value={role.name} onChange={(e)=>setRole({...role,name:e.target.value.toUpperCase()})}/></label><label>Role label<input required value={role.label} onChange={(e)=>setRole({...role,label:e.target.value})}/></label></div>
        <fieldset className="role-picker"><legend>Privileges</legend>{[...new Set([...PRIVILEGE_OPTIONS,...roles.flatMap((item)=>item.privileges||[])])].map((privilege)=><label key={privilege}><input type="checkbox" checked={(role.privileges||[]).includes(privilege)} onChange={()=>setRole({...role,privileges:toggle(role.privileges||[],privilege)})}/>{privilege}</label>)}</fieldset>
        <div className="profile-actions"><button className="primary-action">{editingRole?"Save role":"Create role"}</button><button type="button" className="quiet" onClick={()=>{setRole(emptyRole);setEditingRole("");}}>Clear</button></div>
      </form>
      <div className="ff-card"><h2>Roles</h2><div className="admin-list">{roles.map((item)=><article className="admin-row" key={item.name}><div><strong>{item.name}</strong><span>{item.label}</span><small>{(item.privileges||[]).join(", ")||"No privileges"}</small></div><div className="row-actions"><button type="button" className="quiet" onClick={()=>{setRole(item);setEditingRole(item.name);}}>Edit</button><button type="button" className="quiet danger-action" onClick={()=>deleteRole(item.name)}>Delete</button></div></article>)}</div></div>
    </> : <>
      <form className="ff-card admin-form" onSubmit={saveUser}>
        <h2>{editingUser?"Edit "+editingUser:"Create user"}</h2>
        <div className="profile-grid"><label>Username<input required disabled={Boolean(editingUser)} value={user.username} onChange={(e)=>setUser({...user,username:e.target.value})}/></label><label>First name<input required value={user.first_name} onChange={(e)=>setUser({...user,first_name:e.target.value})}/></label><label>Last name<input required value={user.last_name} onChange={(e)=>setUser({...user,last_name:e.target.value})}/></label><label>Email<input type="email" value={user.email} onChange={(e)=>setUser({...user,email:e.target.value})}/></label><label>Active<select value={user.active?"true":"false"} onChange={(e)=>setUser({...user,active:e.target.value==="true"})}><option value="true">Active</option><option value="false">Inactive</option></select></label></div>
        <fieldset className="role-picker"><legend>Assign Fab Group</legend>{groups.map((item)=><label key={item.group_id}><input type="checkbox" checked={(user.fab_groups||[]).includes(item.group_id)} onChange={()=>setUser({...user,fab_groups:toggle(user.fab_groups||[],item.group_id)})}/>{item.group_id} · {item.name}</label>)}</fieldset>
        <fieldset className="role-picker"><legend>Assign roles</legend>{roles.map((item)=><label key={item.name}><input type="checkbox" checked={(user.roles||[]).includes(item.name)} onChange={()=>setUser({...user,roles:toggle(user.roles||[],item.name)})}/>{item.name} · {item.label}</label>)}</fieldset>
        <div className="profile-actions"><button className="primary-action">{editingUser?"Save user":"Create user"}</button><button type="button" className="quiet" onClick={()=>{setUser(emptyUser);setEditingUser("");}}>Clear</button></div>
      </form>
      <div className="ff-card"><h2>Users</h2><div className="admin-list">{users.map((item)=><article className="admin-row" key={item.username}><div><strong>{item.first_name} {item.last_name}</strong><span>{item.username} · {item.email}</span><small>{(item.roles||[]).join(", ")} · {(item.fab_groups||[]).join(", ")||"No Fab Groups"} · {item.active?"Active":"Inactive"}</small></div><div className="row-actions"><button type="button" className="quiet" onClick={()=>{setUser({username:item.username,first_name:item.first_name||"",last_name:item.last_name||"",email:item.email||"",roles:item.roles||[],fab_groups:item.fab_groups||[],active:item.active});setEditingUser(item.username);}}>Edit</button><button type="button" className="quiet danger-action" disabled={item.username===me?.sub} onClick={()=>deleteUser(item.username)}>Delete</button></div></article>)}</div></div>
    </>}
  </section>;
}
