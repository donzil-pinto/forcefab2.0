import { useEffect, useState } from "react";
import { callApi } from "../api.js";
import { go, PageHead } from "./kit.jsx";

const COLUMNS = [
  ["id", "Case ID"], ["account_id", "Account ID"], ["segment", "Segment"],
  ["site", "Site"], ["region", "Region"], ["created_at", "Created At"],
  ["owner_id", "Owner"], ["severity", "Severity"], ["amount", "Amount"],
];

export function Approvals({ t, onUnauth }) {
  const [items, setItems] = useState(null);
  const [error, setError] = useState("");
  useEffect(() => {
    callApi("/api/cases/approval-inbox").then((response) => {
      if (response.status === 401) { onUnauth(); return; }
      if (response.status >= 400) { setError(response.data?.message || "Unable to load approvals."); return; }
      setItems(response.data?.items || []);
    }).catch(() => setError("Unable to load approvals."));
  }, [onUnauth]);
  return <div>
    <PageHead kicker="Operations" title={t("page.approvals.title")} sentence="Cases currently pending approval." />
    {error ? <p role="alert">{error}</p> : null}
    {items === null && !error ? <p role="status">Loading approvals.</p> : null}
    {items ? <section className="ff-card">
      <div className="evidence-scroll"><table className="approval-queue"><thead><tr>{COLUMNS.map(([, label]) => <th key={label}>{label}</th>)}</tr></thead>
        <tbody>{items.map((item) => <tr key={item.id} onClick={() => go(`/case-details/${encodeURIComponent(item.id)}`)}>
          {COLUMNS.map(([key]) => <td key={key}>{key === "id" ? <button type="button" className="case-open-link" onClick={(event) => { event.stopPropagation(); go(`/case-details/${encodeURIComponent(item.id)}`); }}>{item.id}</button> : item[key] == null || item[key] === "" ? "—" : String(item[key])}</td>)}
        </tr>)}</tbody></table></div>
      {!items.length ? <p>No cases are awaiting approval.</p> : null}
    </section> : null}
  </div>;
}
