import { useState } from "react";
import { go, PageHead, useFetch } from "./kit.jsx";

const WINDOWS = [["all", "All Time"], ["24h", "24 Hours"], ["7d", "7 Days"], ["30d", "30 Days"]];

function Bars({ rows, labelKey, countKey, color, onOpen }) {
  const max = Math.max(1, ...rows.map((row) => Number(row[countKey] || 0)));
  return <div className="ff-vbars">{rows.map((row) => {
    const count = Number(row[countKey] || 0);
    return <button type="button" className="ff-vbar" key={String(row[labelKey])} onClick={() => onOpen(row)} title={`${row[labelKey]}: ${count}`}>
      <span className="ff-vbar-value">{count}</span><span className="ff-vbar-track"><span style={{ height: `${Math.max(3, count / max * 100)}%`, background: color }} /></span><span className="ff-vbar-label">{row[labelKey] || "Unknown"}</span>
    </button>;
  })}</div>;
}

export function Dashboard({ t, fab, onUnauth }) {
  const [windowKey, setWindowKey] = useState("all");
  const [refresh, setRefresh] = useState(0);
  const query = new URLSearchParams({ window: windowKey, refresh: String(refresh) });
  if (fab) query.set("fab", fab);
  const dash = useFetch(`/api/dashboard?${query}`, onUnauth);
  if (dash.loading) return <p role="status">Loading the dashboard.</p>;
  if (dash.error) return <p role="status">{dash.error}</p>;
  const data = dash.data;
  const cases = data.case_rows || [];
  const openCount = cases.length;
  const critical = cases.filter((row) => /critical|high/i.test(row.severity || "")).length;
  const feeds = data.partner_feed_statuses || [];
  const policies = data.policy_exception_outcomes || [];
  const costs = data.operating_cost_totals || {};
  const cards = [
    ["Total Open Cases", openCount, "all open cases", "/cases?status=OPEN"],
    ["Total Critical Open", critical, "high or critical severity", "/cases?severity=HIGH"],
    ["Partner Feeds", feeds.reduce((sum, row) => sum + Number(row.count || 0), 0), feeds.map((row) => `${String(row.status || "").toLowerCase().replace(/^./, (x) => x.toUpperCase())}: ${row.count}`).join(" · ") || "No feeds", "/partner-feeds"],
    ["Total Lot Holds", data.lot_hold_count || 0, "lots with engineering hold", "/fab-lots?engineering_hold=Yes"],
    ["Total Policy Exceptions", policies.reduce((sum, row) => sum + Number(row.count || 0), 0), policies.map((row) => `${row.outcome}: ${row.count}`).join(" · ") || "No exceptions", "/policy-exceptions"],
    ["Total Operating Cost", `${Number(costs.labor_hours || 0).toLocaleString()} labor hours · $${Number(costs.infrastructure_usd || 0).toLocaleString()} infrastructure`, "Measured sums from operating_costs", "/operating-costs"],
  ];
  const statusRows = (data.open_cases?.by_status || []).filter((row) => row.status !== "CLOSED");
  const ageBins = [["0–7 days", 7], ["8–30 days", 30], ["31–90 days", 90], ["90+ days", Infinity]];
  const aging = [...new Set(cases.map((row) => row.severity || "Unknown"))].sort().map((severity) => ({ severity, counts: ageBins.map(() => 0) }));
  cases.forEach((row) => { const age = Math.max(0, Math.floor(((Date.parse(data.case_as_of || "") || Date.now()) - Date.parse(row.created_at || "")) / 86400000)); const index = age <= 7 ? 0 : age <= 30 ? 1 : age <= 90 ? 2 : 3; const group = aging.find((item) => item.severity === (row.severity || "Unknown")); if (group) group.counts[index] += 1; });
  const maxAge = Math.max(1, ...aging.map((row) => row.counts.reduce((sum, value) => sum + value, 0)));
  return <div className="dashboard-page">
    <div className="dashboard-topbar"><PageHead kicker="FabForce2.0" title={t("page.dashboard.title")} sentence="" />
      <div className="dashboard-controls"><label>Time range<select value={windowKey} onChange={(event) => setWindowKey(event.target.value)}>{WINDOWS.map(([value, label]) => <option key={value} value={value}>{label}</option>)}</select></label><button type="button" className="primary" onClick={() => setRefresh((value) => value + 1)}>Refresh</button></div>
    </div>
    <section className="dashboard-metrics">{cards.map(([label, value, detail, path]) => <button type="button" className="ff-card metric-card" key={label} onClick={() => go(path)}><strong>{value}</strong><span>{label}</span><small>{detail}</small></button>)}</section>
    <section className="dashboard-charts">
      <article className="ff-card chart-card"><h2>Case Statuses</h2><Bars rows={statusRows} labelKey="status" countKey="n" color="#df765d" onOpen={(row) => go(`/cases?status=${encodeURIComponent(row.status || "")}`)} /></article>
      <article className="ff-card chart-card"><h2>Case Severity</h2><Bars rows={data.open_cases?.by_severity || []} labelKey="severity" countKey="n" color="#62a6a0" onOpen={(row) => go(`/cases?severity=${encodeURIComponent(row.severity || "")}`)} /></article>
      <article className="ff-card chart-card"><h2>Open Cases by Site</h2><Bars rows={data.open_cases?.by_site || []} labelKey="site" countKey="n" color="#d3a64f" onOpen={(row) => go(`/cases?site=${encodeURIComponent(row.site || "")}`)} /></article>
      <article className="ff-card chart-card case-aging-chart"><h2>Case Aging by Severity</h2><div className="aging-legend">{ageBins.map(([label], index) => <span key={label}><i className={`aging-color aging-${index}`} />{label}</span>)}</div><div className="aging-rows">{aging.map((group) => <div className="aging-row" key={group.severity}><strong>{group.severity}</strong><div className="aging-stack">{group.counts.map((count, index) => <span key={index} className={`aging-segment aging-${index}`} title={`${ageBins[index][0]}: ${count} cases`} style={{width: `${count / maxAge * 100}%`}}>{count || ""}</span>)}</div></div>)}</div></article>
    </section>
  </div>;
}
