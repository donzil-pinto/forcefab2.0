import { go, PageHead, useFetch } from "./kit.jsx";

const VIEWS = {
  "partner-feeds": ["partner_feeds", "Partner Feeds", ["feed_id", "partner", "schema_rev", "source_ts", "ref_id", "record_kind", "exception_type"], ["Feed ID", "Location", "Schema Rev", "Source Timestamp", "Case ID", "Record Kind", "Exception Type"]],
  "batch-runs": ["batch_runs", "Batch Runs", ["run_id", "partner", "started_at", "input_count", "accepted_count", "rejected_count", "result"], ["Run ID", "Location", "Started At", "Input Count", "Accepted Count", "Rejected Count", "Result"]],
  "fab-lots": ["wafer_lots", "Fab Lots", ["lot_id", "tool_id", "tool_name", "count", "defect_count", "measured_yield", "engineering_hold"], ["Lot ID", "Tool ID", "Tool Name", "Count", "Defect Count", "Measured Yield", "Engineering Hold"]],
  "policy-exceptions": ["policy_exceptions", "Policy Exceptions", ["exception_id", "ref_id", "policy_code", "outcome", "actor", "recorded_at", "explanation"], ["Exception ID", "Case ID", "Policy Code", "Outcome", "Actor", "Recorded At", "Explanation"]],
  events: ["events", "Events", ["id", "case_id", "recorded_at", "event_type"], ["Event ID", "Case ID", "Recorded At", "Event Type"]],
  "engineering-changes": ["engineering_changes", "Engineering Changes", ["ecn_id", "tool_family", "from_rev", "to_rev", "effective_at", "approval_state"], ["ECN ID", "Tool Family", "From Rev", "To Rev", "Effective At", "Approval State"]],
  "operating-costs": ["operating_costs", "Operating Costs", ["period", "total_cases", "labor_hours", "infrastructure_usd"], ["Period", "Total Cases", "Labor Hours", "Infrastructure Cost"]],
};

const pretty = (value) => value == null || value === "" ? "—" : typeof value === "object" ? JSON.stringify(value) : String(value);

export function Analysis({ route, onUnauth }) {
  const view = VIEWS[route.page];
  const offset = Math.max(0, Number(route.params.get("offset") || 0));
  const query = route.params.get("q") || "";
  const [table, title, keys, labels] = view;
  const data = useFetch(`/api/analysis/${table}?limit=200&offset=${offset}&q=${encodeURIComponent(query)}`, onUnauth);
  const rows = data.data?.items || [];
  const next = (value) => {
    const params = new URLSearchParams(route.params);
    params.set("offset", String(value));
    go(`/${route.page}?${params.toString()}`);
  };
  return <div>
    <PageHead kicker="Analysis & Audit" title={title} sentence={`Read-only ${title.toLowerCase()} from the legacy database.`} />
    <form className="ff-filters" onSubmit={(event) => { event.preventDefault(); const value = new FormData(event.currentTarget).get("q") || ""; go(`/${route.page}?q=${encodeURIComponent(value)}`); }}>
      <label>Search all columns<input name="q" defaultValue={query} /></label><button className="primary" type="submit">Search</button>
    </form>
    {data.loading ? <p role="status">Loading {title.toLowerCase()}…</p> : null}
    {data.error ? <p role="alert">{data.error}</p> : null}
    {data.data ? <>
      <p>{data.data.total} records · showing {data.data.total ? offset + 1 : 0}–{offset + rows.length}</p>
      <div className="evidence-scroll"><table className="analysis-table"><thead><tr>{labels.map((label) => <th key={label}>{label}</th>)}</tr></thead><tbody>
        {rows.map((row, index) => <tr key={row[keys[0]] || index}
          className={[table === "events" ? "event-row" : "", table === "wafer_lots" ? "fab-lot-row" : ""].filter(Boolean).join(" ") || undefined}
          onClick={table === "wafer_lots" ? () => go(`/lots/${encodeURIComponent(row.lot_id)}`) : undefined}
          onKeyDown={table === "wafer_lots" ? (event) => { if (event.key === "Enter" || event.key === " ") { event.preventDefault(); go(`/lots/${encodeURIComponent(row.lot_id)}`); } } : undefined}
          tabIndex={table === "wafer_lots" ? 0 : undefined}
          role={table === "wafer_lots" ? "link" : undefined}
          aria-label={table === "wafer_lots" ? `Open lot ${row.lot_id} in Lot Genealogy & SPC` : undefined}
          title={table === "wafer_lots" ? `Open lot ${row.lot_id} in Lot Genealogy & SPC` : undefined}>
          {keys.map((key, column) => <td key={key} className={table === "events" && column === keys.length - 1 ? "event-payload-cell" : undefined}>
            {table === "wafer_lots" && key === "lot_id" ? <button type="button" className="case-open-link" onClick={(event) => { event.stopPropagation(); go(`/lots/${encodeURIComponent(row.lot_id)}`); }}>{pretty(row[key])}</button> : null}
            {table === "events" && key === "case_id" ? <button type="button" className="case-open-link" onClick={(event) => { event.stopPropagation(); go(`/cases/${encodeURIComponent(row.case_id)}`); }}>{pretty(row[key])}</button> : null}
            {!(table === "wafer_lots" && key === "lot_id") && !(table === "events" && key === "case_id") ? pretty(row[key]) : null}
            {table === "events" && column === keys.length - 1 ? <div className="event-payload" role="tooltip"><strong>Event payload</strong>{Object.entries(row.payload || {}).map(([name, value]) => <div key={name}><small>{name}</small><span>{pretty(value)}</span></div>)}</div> : null}
          </td>)}
        </tr>)}
      </tbody></table></div>
      {rows.length === 0 ? <p>No records match this search.</p> : null}
      <div className="profile-actions"><button type="button" className="quiet" disabled={offset <= 0} onClick={() => next(Math.max(0, offset - 200))}>Previous</button><button type="button" className="quiet" disabled={offset + rows.length >= data.data.total} onClick={() => next(offset + 200)}>Next</button></div>
    </> : null}
  </div>;
}
