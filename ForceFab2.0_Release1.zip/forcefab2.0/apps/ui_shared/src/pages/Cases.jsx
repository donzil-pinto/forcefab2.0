import { AskPanel, go, PageHead, Quiet, useFetch } from "./kit.jsx";

function ageDays(value) {
  const then = Date.parse(value || "");
  return Number.isNaN(then) ? "Unknown" : `${Math.max(0, Math.floor((Date.now() - then) / 86400000))} days`;
}

export function Cases({ t, fab, lineage, route, onUnauth, onStepUp }) {
  const params = route.params;
  const caseId = route.parts[1] ? decodeURIComponent(route.parts[1]) : "";
  const query = new URLSearchParams();
  ["status", "severity", "segment", "q", "site"].forEach((key) => { if (params.get(key)) query.set(key, params.get(key)); });
  if (fab && !query.has("site")) query.set("fab", fab);
  query.set("limit", "200");
  const list = useFetch(`/api/cases?${query}`, onUnauth);
  const detail = useFetch(caseId ? `/api/cases/${encodeURIComponent(caseId)}/detail` : "", onUnauth);
  const rows = (list.data?.items || []).filter((row) => row.status !== "CLOSED");
  return <div>
    <PageHead kicker="FabForce2.0" title={t("page.cases.title")} sentence="Search, filter and assign work within your permitted site scope" />
    {params.get("q") ? <p>Search results for “{params.get("q")}".</p> : null}
    {list.loading ? <p role="status">Loading cases.</p> : null}
    {list.error ? <p role="status">{list.error}</p> : null}
    <div className="ff-split cases-layout">
      <section className="ff-card cases-table-card">
        <h2>Open Cases</h2>
        <div className="evidence-scroll"><table className="cases-table"><thead><tr>{["Case ID", "Account ID", "Segment", "Site", "Region", "Created At", "Owner", "Status", "Severity", "Amount"].map((x) => <th key={x}>{x}</th>)}</tr></thead>
          <tbody>{rows.map((row) => <tr key={row.id} className="case-row" title={`Note: ${row.note || "—"} | Version: ${row.version || "1"}`} aria-current={row.id === caseId ? "true" : undefined} onClick={() => go(`/case-details/${encodeURIComponent(row.id)}?${params.toString()}`)}>
            <td><button type="button" className="case-open-link" onClick={(event) => { event.stopPropagation(); go(`/case-details/${encodeURIComponent(row.id)}?${params.toString()}`); }}>{row.id}</button></td>
            <td>{row.account_id || "—"}</td><td>{row.segment || "Exception"}</td><td>{row.site || "—"}</td><td>{row.region || row.sales_region || "—"}</td><td>{row.created_at || "—"}</td><td>{row.owner_id || "Unassigned"}</td><td>{row.status}</td><td>{row.severity || "Unknown"}</td><td>{row.amount ?? "—"}</td>
          </tr>)}</tbody></table></div>
        {!rows.length && !list.loading ? <p>No open cases match these filters.</p> : null}
      </section>
      {caseId ? <section className="ff-card case-detail-card">
        {caseId && detail.loading ? <p role="status">Loading case details.</p> : null}
        {detail.error ? <p role="alert">{detail.error}</p> : null}
        {detail.data?.case ? <article className="case-form">
          <div className="case-form-title"><h2>Case {detail.data.case.id}</h2><span className="status-chip">{detail.data.case.status}</span></div>
          <dl className="case-fields">{[["Lot #", "Not linked in source data"], ["Severity", detail.data.case.severity], ["Type", detail.data.case.segment], ["Site", detail.data.case.site], ["Status", detail.data.case.status], ["Owner", "Unassigned"], ["Created", detail.data.case.created_at], ["Age", ageDays(detail.data.case.created_at)], ["Account", detail.data.case.account_id], ["Amount", detail.data.case.amount], ["Description", detail.data.case.note]].map(([label, value]) => <div key={label}><dt>{label}</dt><dd>{value == null ? "—" : String(value)}</dd></div>)}</dl>
          <h3>Timeline</h3>{(detail.data.timeline || []).length ? <ol className="case-timeline">{detail.data.timeline.map((row, index) => <li key={index}><time>{row.recorded_at || row.occurred_at || ""}</time><span>{row.event_type || row.kind || row.note || "Event"}</span></li>)}</ol> : <p>No timeline events are recorded.</p>}
          <p>{detail.data.link_note}</p>
          <AskPanel lineage={lineage} subject="case" id={caseId} onUnauth={onUnauth} onStepUp={onStepUp} />
        </article> : null}
      </section> : null}
    </div>
  </div>;
}
