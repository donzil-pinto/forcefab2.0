import { go, PageHead, useFetch } from "./kit.jsx";

export function Search({ t, route, onUnauth }) {
  const query = route.params.get("q") || "";
  const results = useFetch(query ? `/api/search?q=${encodeURIComponent(query)}` : "", onUnauth);
  return <section>
    <PageHead kicker="FabForce2.0" title="Search Results" sentence={query ? `Results for “${query}” across available application data.` : "Enter a search term in the header."} />
    {results.loading ? <p role="status">Searching application data.</p> : null}
    {results.error ? <p role="alert">{results.error}</p> : null}
    <div className="search-results">{(results.data?.items || []).map((item, index) => <button type="button" key={`${item.type}-${item.id}-${index}`} className="ff-card search-result" onClick={() => go(item.href)}><span>{item.type}</span><strong>{item.id}</strong><small>{item.summary}</small></button>)}</div>
    {results.data && !results.data.items?.length ? <p>No results found.</p> : null}
  </section>;
}
