import { useEffect, useState } from "react";
import { callApi } from "../api.js";

export function UserProfile({ me, setMe, locale, setLocale, theme, setTheme }) {
  const [profile, setProfile] = useState(null);
  const [status, setStatus] = useState("");
  const [busy, setBusy] = useState(false);
  const spanish = locale === "es";

  useEffect(() => {
    let live = true;
    callApi("/api/identity/profile").then(({status, data}) => {
      if (!live) return;
      if (status === 200) {
        setProfile(data.profile);
        setLocale(data.profile.language || "en");
        setTheme(data.profile.theme || "dark");
      } else setStatus(data.message || "Unable to load profile.");
    }).catch(() => setStatus("Unable to load profile."));
    return () => { live = false; };
  }, []);

  function edit(key, value) { setProfile((current) => ({...current, [key]: value})); }

  async function save(event) {
    event.preventDefault();
    setBusy(true); setStatus("");
    const {status, data} = await callApi("/api/identity/profile", me, {method:"PATCH", body:{
      first_name: profile.first_name, last_name: profile.last_name, email: profile.email,
      language: profile.language, theme: profile.theme,
    }});
    setBusy(false);
    if (status >= 200 && status < 300) {
      setProfile(data.profile);
      setMe((current) => ({...current, name: data.profile.name, first_name: data.profile.first_name, last_name: data.profile.last_name, email: data.profile.email, roles: data.profile.roles, sites: data.profile.sites, fab_groups: data.profile.fab_groups}));
      setLocale(data.profile.language); setTheme(data.profile.theme);
      setStatus(spanish ? "Perfil guardado." : "Profile saved.");
    } else setStatus(data.message || "Unable to save profile.");
  }

  if (!profile) return <section className="console"><h1 className="ff-title">{spanish ? "Perfil de usuario" : "User Profile"}</h1><p role="status">{status || (spanish ? "Cargando perfil…" : "Loading profile…")}</p></section>;
  return <section className="console">
    <header className="ff-page-head"><p className="band-kicker">FabForce2.0</p><h1 className="ff-title">{spanish ? "Perfil de usuario" : "User Profile"}</h1><p>{spanish ? "Actualice sus datos de contacto y preferencias." : "Update your contact details and preferences."}</p></header>
    <form className="ff-card profile-form" onSubmit={save}>
      <div className="profile-grid">
        <label>{spanish ? "Nombre" : "First name"}<input required value={profile.first_name || ""} onChange={(e)=>edit("first_name",e.target.value)} /></label>
        <label>{spanish ? "Apellido" : "Last name"}<input required value={profile.last_name || ""} onChange={(e)=>edit("last_name",e.target.value)} /></label>
        <label className="wide">{spanish ? "Correo electrónico" : "Email address"}<input required type="email" value={profile.email || ""} onChange={(e)=>edit("email",e.target.value)} /></label>
        <label>{spanish ? "Idioma" : "Language"}<select value={profile.language || "en"} onChange={(e)=>edit("language",e.target.value)}><option value="en">English</option><option value="es">Español</option></select></label>
        <label>{spanish ? "Tema" : "Theme"}<select value={profile.theme || "dark"} onChange={(e)=>edit("theme",e.target.value)}><option value="light">{spanish ? "Claro" : "Light"}</option><option value="dark">{spanish ? "Oscuro" : "Dark"}</option></select></label>
      </div>
      <dl className="profile-list">
        <div><dt>{spanish ? "Rol" : "Role"}</dt><dd>{(profile.roles || []).map((role,i)=><span key={role} className="role-chip">{role} · {(profile.role_labels || [])[i] || role}</span>)}</dd></div>
        <div><dt>{spanish ? "Grupo Fab asignado" : "Assigned Fab Group"}</dt><dd>{(profile.fab_group_details || []).map((group)=><span key={group.group_id} className="role-chip">{group.group_id} · {group.name}</span>)}{!(profile.fab_group_details || []).length ? (spanish ? "Sin grupos asignados" : "No Fab Groups assigned") : null}</dd></div>
        <div><dt>{spanish ? "Sitios asignados" : "Assigned sites"}</dt><dd>{(profile.sites || []).join(", ") || (spanish ? "Sin sitios" : "No sites assigned")}</dd></div>
        <div><dt>{spanish ? "Usuario" : "Username"}</dt><dd>{profile.username}</dd></div>
      </dl>
      <div className="profile-actions"><button className="primary-action" disabled={busy}>{busy ? (spanish ? "Guardando…" : "Saving…") : (spanish ? "Guardar cambios" : "Save changes")}</button>{status ? <span role="status">{status}</span> : null}</div>
    </form>
  </section>;
}
